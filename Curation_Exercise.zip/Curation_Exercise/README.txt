Curation Exercise 

This exercise is designed to help you understand what makes a dataset complete, understandable, and reusable.

Step 1. Choose a dataset
Select any published dataset from a repository.
Examples:
- Research Data Gouv
- Zenodo
- Nakala

Any dataset can be used.

Step 2. Explore the dataset
Open the dataset page and review:
- files 
- description
- metadata
- documentation

Do not download everything immediately. First, observe what is available.

Step 3. Take the role of a curator
Evaluate the dataset as if you were a data curator. 

Main question:
Can this dataset be understood and reused by someone else?

Step 4. Evaluate the dataset
Open the curation form and start evaluating. 

Overall idea:
Could you reuse this dataset without contacting the author? Is there any unanswered question in your mind when you review it?

Step 5. Conclusion

Decide whether the dataset is:
- complete
- understandable
- reusable

If not, identify what is missing or unclear.

Purpose of the exercise

This exercise helps you understand that data sharing is not only about depositing files.
It is about making sure that data remain interpretable and reusable by others.

Source and attribution

The materials in this training are adapted from:
Curation report template of Recherche Data Gouv
https://recherche.data.gouv.fr/en/category/33/guide/curation-report-template

Content reused under Licence Ouverte 2.0 (Etalab).
Adapted and translated for educational purposes.